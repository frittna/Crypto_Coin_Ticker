# M5Burner_NightscoutMon
Standalone programmer for the M5Stack_NightscoutMon project
Courtesy M5STACK (Shenzhen Mingzhan Information Technology Co., Ltd.) with authorization to redistribute

Make sure the path to M5Burner.exe doesn't contain spaces.
This package comes with revision 2 May 2019 of https://github.com/mlukasek/M5_NightscoutMon 
