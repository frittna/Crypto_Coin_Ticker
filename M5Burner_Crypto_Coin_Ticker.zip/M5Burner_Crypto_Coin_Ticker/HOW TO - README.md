# M5Burner with Bitcoin_Multi_Coin_Ticker

Make sure the path to M5Burner.exe doesn't contain spaces !

  1.  Start M5Burner.exe
  2.  Select proper COM Port of your M5 Stack
  3.  Select 921600 Baud 
  4.  Select Firmware: Bitcoin_Multi_Crypto_Coin_Ticker
  5.  press Burn
  6.  copy the "ccticker.cfg" to the root of your SD Card (best Filesystem: FAT32)
  7.  modify "ccticker.cfg" file with a simple text editor for your WiFi settings, favourite coinpairs and names/colors for it










This package comes with revision 1.0.4 - spiffs and SDConfig Version of my Bitcoin / Multi Crypto Coin Price Ticker from https://github.com/frittna/Crypto_Coin_Ticker - Apr. 2021
