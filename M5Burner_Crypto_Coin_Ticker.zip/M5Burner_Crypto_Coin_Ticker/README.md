# M5Burner_Bitcoin_Multi_Coin_Ticker

Make sure the path to M5Burner.exe doesn't contain spaces !

This package comes with revision 1.0.4 of my Bitcoin / Multi Crypto Coin Price Ticker from https://github.com/frittna/Crypto_Coin_Ticker - Apr. 2021


  1.  Start M5Burner.exe
  2.  Select proper COM Port of your M5 Stack
  3.  Select 921600 Baud 
  4.  Select Firmware: Bitcoin_Multi_Crypto_Coin_Ticker
  5.  press Burn
  6.  copy my folder "ccticker" on the root of your SD Card (best Filesystem: FAT32)
  7.  modify the "ccticker.cfg" file with a simple text editor for your WiFi settings, favourite coinpairs and names/colors for it
