# M5Burner with Bitcoin_Multi_Coin_Ticker    -    Nov.21.2024

Make sure the folder path to the M5Burner.exe doesn't contain spaces in its name or it will not work !

  1.  Start M5Burner.exe
  2.  Select proper COM Port of your M5 Stack
  3.  Select 921600 Baud for example
  4.  Select Firmware: Bitcoin_Multi_Crypto_Coin_Ticker
  5.  press Burn
  6.  copy the "ccticker.cfg" to the root of your SD Card (best Filesystem: FAT32)
  7.  modify "ccticker.cfg" file with a simple text editor for your WiFi settings, language/timezone/coinpairs/names/colors etc and save it
  8.  don't forget to safe-eject the SD-card in your OS to avoid file corruption on the txt file
  9. insert SD-Card in your M5Stack and restart

-->  afterwards you can eject the SD-Card if you want, the settings will be stored
-->  if you hold button B at Startup it will clear all user settings from internal memory

--> read instructions to get used to the button commands





